import json, pathlib, os
p=pathlib.Path('/tmp/v6-a05-cp27'); retained={}
for name in ['runtime-observed-owned-observations.json','wider-observed-owned-observations.json','narrow-diagnostic-owned-observations.json','shell-red-owned-observations.json','shell-final-red-owned-observations.json','shell-green-owned-observations.json']:
 for x in json.loads((p/name).read_text()):
  retained[(x['pid'],x['start'])]={k:x[k] for k in ['pid','start','pgid','sid']}
values=[]
for x in retained.values():
 try: stat=pathlib.Path(f"/proc/{x['pid']}/stat").read_text()
 except OSError as e: stat=e.__class__.__name__+':'+str(e.errno)
 try: os.kill(x['pid'],0); zero='live'
 except OSError as e: zero=e.__class__.__name__+':'+str(e.errno)
 values.append(dict(x,stat=stat,killZero=zero))
(p/'final-absence.json').write_text(json.dumps(values,indent=2))
print({'retainedIdentities':len(values),'absent':sum(x['stat']=='FileNotFoundError:2' and x['killZero']=='ProcessLookupError:3' for x in values)})
