import json, re, os, errno, hashlib, pathlib, subprocess
root=pathlib.Path.cwd(); out=pathlib.Path('/tmp/v6-a05-residue')
pids=set()
for log in out.glob('*.txt'):
 pids.update(int(p) for p in re.findall(r'"pid":\s*(\d+)',log.read_text()))
observations=[]
for pid in sorted(pids):
 try: stat=pathlib.Path(f'/proc/{pid}/stat').read_text()
 except OSError as e: stat=errno.errorcode.get(e.errno,str(e.errno))
 try: os.kill(pid,0); kill='live'
 except OSError as e: kill=errno.errorcode.get(e.errno,str(e.errno))
 observations.append(dict(pid=pid,stat=stat,killZero=kill))
result={'observations':observations,'allAbsent':all(r['stat']=='ENOENT' and r['killZero']=='ESRCH' for r in observations),'node':subprocess.check_output(['node','--version'],text=True).strip(),'tmux':subprocess.check_output(['/tmp/ao-tmux-tools/bin/tmux','-V'],text=True).strip(),'tmuxSha256':hashlib.sha256(pathlib.Path('/tmp/ao-tmux-tools/bin/tmux').read_bytes()).hexdigest()}
with (out/'final-absence.json').open('x') as f: json.dump(result,f,indent=2)
print(json.dumps({'emittedPidCount':len(observations),'allAbsent':result['allAbsent'],'node':result['node'],'tmux':result['tmux']}))
