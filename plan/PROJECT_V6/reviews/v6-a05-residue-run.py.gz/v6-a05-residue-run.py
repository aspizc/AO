import sys, os, json, pathlib, importlib.util, dataclasses, hashlib
root=pathlib.Path.cwd()
spec=importlib.util.spec_from_file_location('a05_ci_gate',root/'scripts/ci_gate.py'); gate=importlib.util.module_from_spec(spec); sys.modules[spec.name]=gate; spec.loader.exec_module(gate)
name=sys.argv[1]
pattern=sys.argv[2]
argv=['node','--test','--test-concurrency=1','--test-name-pattern='+pattern,'tests/gateway/request_context_reattach.test.js']
outdir=pathlib.Path('/tmp/v6-a05-residue'); env=dict(os.environ); env['PATH']='/tmp/ao-tmux-tools/bin:'+env['PATH']
metadata={'argv':argv,'cwd':str(root),'PATHprefix':'/tmp/ao-tmux-tools/bin','head':os.popen('git rev-parse HEAD').read().strip(),'sourceSha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pathlib.Path('gateway/src/adapters/request_launch_cleanup.js'),pathlib.Path('gateway/src/adapters/tmux_client.js'),pathlib.Path('scripts/ci_gate.py'),pathlib.Path('tests/gateway/request_context_reattach.test.js')]}}
(outdir/(name+'-command.json')).write_text(json.dumps(metadata,indent=2))
result=gate._execute_command(argv,root,env,900)
with (outdir/(name+'.txt')).open('xb') as log: log.write(result.stdout); log.write(result.stderr)
(outdir/(name+'-outcome.json')).write_text(json.dumps({k:v for k,v in dataclasses.asdict(result).items() if k not in ('stdout','stderr')},indent=2))
print(json.dumps({'run':name,'status':result.status,'returncode':result.returncode}),flush=True)
sys.exit(0 if result.status=='completed' and result.returncode==0 else 1)
