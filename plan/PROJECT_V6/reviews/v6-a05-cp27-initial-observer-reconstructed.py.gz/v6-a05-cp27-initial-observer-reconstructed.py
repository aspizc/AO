import sys, os, json, pathlib, importlib.util, dataclasses, hashlib
root=pathlib.Path.cwd()
spec=importlib.util.spec_from_file_location('a05_ci_gate',root/'scripts/ci_gate.py'); gate=importlib.util.module_from_spec(spec); sys.modules[spec.name]=gate; spec.loader.exec_module(gate)
name=sys.argv[1]
pattern=sys.argv[2]
argv=['node','--test','--test-concurrency=1','--test-name-pattern='+pattern,'tests/gateway/request_context_reattach.test.js']
if name=='focused-final': argv.append('tests/gateway/request_launch_observation.test.js')
if name.startswith('wider-'):
 files=sorted(set(root.glob('tests/gateway/request_context*.test.js')) | set(root.glob('tests/gateway/*reattach*.test.js')))
 files += [root/p for p in ['tests/gateway/state_init.test.js','tests/gateway/sqlite_migrations.test.js','tests/gateway/coordination_consumer_epoch_migrations.test.js','tests/gateway/lifecycle_rebaseline_core_repository.test.js','tests/gateway/lifecycle_rebaseline_core_service.test.js','tests/gateway/tool_catalog.test.js','tests/gateway/tool_projection_contract.test.js','tests/gateway/tool_error_serialization.test.js','tests/gateway/request_launch_observation.test.js','tests/gateway/task_service.test.js','tests/gateway/mcp_bootstrap.test.js','gateway/tests/scaffold.test.js','tests/gateway/tool_coordination_registry.test.js','tests/gateway/tool_orchestration_task.test.js','tests/gateway/orchestrator_profile_contract.test.js','tests/gateway/tool_agent.test.js','tests/gateway/tool_agent_model.test.js','tests/gateway/agent_errors.test.js']]
 argv=['node','--test','--test-concurrency=1']+sorted(set(str(p.relative_to(root)) for p in files))

outdir=pathlib.Path('/tmp/v6-a05-cp27'); env=dict(os.environ); env['PATH']='/tmp/ao-tmux-tools/bin:'+env['PATH']
metadata={'argv':argv,'cwd':str(root),'PATHprefix':'/tmp/ao-tmux-tools/bin','head':os.popen('git rev-parse HEAD').read().strip(),'sourceSha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pathlib.Path('gateway/src/adapters/request_launch_cleanup.js'),pathlib.Path('gateway/src/adapters/tmux_client.js'),pathlib.Path('scripts/ci_gate.py'),pathlib.Path('tests/gateway/request_context_reattach.test.js')]}}
(outdir/(name+'-command.json')).write_text(json.dumps(metadata,indent=2))
import threading, time
stop = threading.Event()
observations=[]
seen={}
def observe():
 while not stop.is_set():
  pending=[os.getpid()]; visited=set()
  while pending:
   pid=pending.pop()
   if pid in visited: continue
   visited.add(pid)
   try:
    for task in pathlib.Path(f'/proc/{pid}/task').iterdir():
     pending.extend(int(x) for x in (task/'children').read_text().split())
    if pid==os.getpid(): continue
    raw=pathlib.Path(f'/proc/{pid}/stat').read_text(); fields=raw.rsplit(') ',1)[1].split()
    key=(pid,fields[19]); state=(fields[0],fields[1])
    if seen.get(key)!=state:
     seen[key]=state
     observations.append({'at':time.monotonic(),'pid':pid,'start':fields[19],'state':fields[0],'ppid':int(fields[1]),'pgid':int(fields[2]),'sid':int(fields[3]),'stat':raw,'cmdline':pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace')})
   except (OSError,ValueError): pass
  stop.wait(.01)
thread=threading.Thread(target=observe);thread.start()
try: result=gate._execute_command(argv,root,env,900)
finally:
 stop.set();thread.join()
 (outdir/(name+'-owned-observations.json')).write_text(json.dumps(observations,indent=2))
with (outdir/(name+'.txt')).open('xb') as log: log.write(result.stdout); log.write(result.stderr)
(outdir/(name+'-outcome.json')).write_text(json.dumps({k:v for k,v in dataclasses.asdict(result).items() if k not in ('stdout','stderr')},indent=2))
print(json.dumps({'run':name,'status':result.status,'returncode':result.returncode}),flush=True)
sys.exit(0 if result.status=='completed' and result.returncode==0 else 1)
